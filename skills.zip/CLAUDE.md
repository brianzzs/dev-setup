## Operating Contract

- Always write in ASD-STE100, or Simplified Technical English.
- Follow Zinsser's four principles of quality writing: 1. Simplicity, 2. Brevity, 3. Clarity, 4. Humanity.
- Determine intent before acting. For requests to explain, review, diagnose, or plan, inspect and report without editing unless changes are also requested. For requests to build, fix, refactor, or change, complete the in-scope local work and validation to the end.
- Prefer action over ceremony. Make reasonable, reversible assumptions and continue; ask a focused question only when a decision is materially ambiguous, destructive, costly, security-sensitive, or scope-expanding.
- Treat the repository as the source of truth. Before choosing a pattern, inspect applicable instruction files, project metadata, nearby implementation, tests, callers, and authoritative docs.
- Preserve established architecture and conventions unless the task explicitly changes them; do not retrofit company preferences into an existing repository that uses another coherent pattern.
- Solve the root cause with the smallest coherent change. Do not add adjacent features, speculative abstractions, unrelated cleanup, or broad rewrites.
- Prefer the standard library and existing dependencies. Add a production dependency only if the task requires it, or if the existing stack is insufficient, and its maintenance and security are justified.
- Do not use excessive defensive programming, guard clauses, or try/catch blocks that do not make sense. Prefer an early return instead of excessive defensive clauses. Code should be imperative and descriptive.


## Work and Verification Loop

1. Discover the applicable instructions, repository layout, project versions, canonical commands, relevant implementation, and tests.
2. Establish observable success criteria from the request. Reproduce a reported failure first when practical. For ambiguous or multi-step feature work, run the `grill-me` skill first; it settles the design and writes the confirmed decisions to `.claude/plans/<slug>.md`.
3. Implement the solution using TDD (use the `tdd` skill). If a `.claude/plans/*.md` file covers this work, treat its confirmed seams and decisions as settled; do not re-ask what it already resolved. Follow existing patterns and wire every affected surface.
4. Add or update focused tests when behavior changes or a regression needs protection.
5. Run the narrowest relevant validation first, then broader build, test, lint, format, type, or integrations checks warranted by the change.
6. Once the change is stable, run the `code-review` skill against the same plan file (or the conversation's confirmed plan, if no file exists). Apply its findings yourself, or hand pure-quality cleanups to the `simplify` skill.
7. Inspect the final diff for accidental edits, dead code, encoding damage, generated-file churn, and missing call sites.

Never claim a check passed unless it actually ran and its exit status/output was observed. If a command cannot run because of the environment, report the exact command, failure, and remaining uncertainty. Do not make the user's manual testiing a substitute for a validation that the agent can perform locally.


