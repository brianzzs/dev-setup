<#
.SYNOPSIS
  Post-migration verification + PR-summary data for a Dapper migration.

.DESCRIPTION
  Step 3 of the dapper-migrate skill. Builds, tests, hunts stale references and
  stray workflow artifacts, and prints the diff facts the PR summary needs.

  Read-only with respect to git: never stages, commits, or pushes.

  Windows PowerShell 5.1 compatible.

.PARAMETER Base
  Branch to diff against for the change summary and for scoping warning checks.

.PARAMETER SkipMvc
  Skip the WIT.UI.MVC build. Faster, but stops catching consumer-side breakage.
  Full run ~95s; -SkipMvc ~45s.

.PARAMETER Incremental
  Skip --no-incremental. Faster, but MSBuild will not re-emit warnings for
  already-built projects, so the warning attribution check goes blind.

.EXAMPLE
  powershell -File .claude/skills/dapper-migrate/verify.ps1
#>
param(
    [string]$Base = 'Release-TLAWTH-36-Replace-Discovery-Dapper',
    [switch]$SkipMvc,
    [switch]$Incremental
)

$ErrorActionPreference = 'Continue'

function Section($msg) { Write-Host ""; Write-Host "== $msg ==" -ForegroundColor Cyan }
function Ok($msg) { Write-Host "  ok  $msg" -ForegroundColor Green }
function Bad($msg) { Write-Host "  XX  $msg" -ForegroundColor Red }
function Note($msg) { Write-Host "  !!  $msg" -ForegroundColor Yellow }

$root = (& git rev-parse --show-toplevel 2>$null)
if ($LASTEXITCODE -ne 0 -or -not $root) { Write-Host "FAIL: not in a git repo" -ForegroundColor Red; exit 1 }
Set-Location ($root -replace '/', '\')

$failures = 0
$branch = (& git rev-parse --abbrev-ref HEAD).Trim()
Write-Host "branch $branch  vs base $Base" -ForegroundColor White

if ($branch -eq $Base) { Note "HEAD is the base branch - the diff will be empty and most checks are vacuous" }

# ---------------------------------------------------------------------------
# The diff drives every scoped check below, so compute it first.
# ---------------------------------------------------------------------------
$diffLines = @(& git diff --name-status -M "$Base...HEAD")
$added = @(); $deletedOrMoved = @(); $movedNames = @()
foreach ($line in $diffLines) {
    if (-not $line) { continue }
    $parts = $line -split "`t"
    $status = $parts[0]
    $dest = $parts[-1]
    if ($status -match '^D') { $deletedOrMoved += $dest }
    else { $added += $dest }
    if ($status -match '^(D|R)') {
        $src = $parts[1]
        if ($src -match '/(I?\w+Service)\.cs$') { $movedNames += $Matches[1] }
    }
}
# Working-tree changes count too - the agent has not committed yet.
foreach ($line in (& git status --porcelain)) {
    if (-not $line) { continue }
    $p = ($line.Substring(3)).Trim().Trim('"')
    # Rename/copy lines are "old -> new" on one porcelain line; only the
    # destination path is a real file on disk today.
    if ($p -match '^(.+?) -> (.+)$') { $p = $Matches[2].Trim().Trim('"') }
    # .json matters: the AppVersionString bump lands in appsettings.json and is
    # verified before it is committed, so it must be picked up here.
    if ($p -match '\.(cs|cshtml|json|csproj)$' -and $line -notmatch '^ ?D') { $added += $p }
}
$added = @($added | Sort-Object -Unique)
$movedNames = @($movedNames | Sort-Object -Unique)
$touchedDataAccess = @($added | Where-Object { $_ -match '^src/WIT\.Data\.Access/.*\.cs$' })

# ---------------------------------------------------------------------------
Section "Build"
$projects = @('src\WIT.Data.Access.Tests\WIT.Data.Access.Tests.csproj')
if (-not $SkipMvc) { $projects += 'src\WIT.UI.MVC\WIT.UI.MVC.csproj' }
$buildArgs = if ($Incremental) { @() } else { @('--no-incremental') }

$myWarnings = @()
foreach ($p in $projects) {
    # Array-expansion, not @splat: splatting into a native command loses the
    # switch in PowerShell 5.1 and MSBuild reports "MSB1001: Unknown switch".
    $argv = @('build', $p) + $buildArgs
    $out = (& dotnet $argv 2>&1 | Out-String)
    $code = $LASTEXITCODE
    $lines = $out -split "`r?`n"
    $ec = [regex]::Match($out, '(\d+) Error\(s\)')
    $wc = [regex]::Match($out, '(\d+) Warning\(s\)')
    $errCount = if ($ec.Success) { [int]$ec.Groups[1].Value } else { -1 }
    $warnCount = if ($wc.Success) { [int]$wc.Groups[1].Value } else { -1 }

    if ($code -ne 0 -or $errCount -gt 0) {
        Bad "$p : $errCount error(s)"
        ($lines | Select-String -Pattern ': error ' | Select-Object -First 15) |
            ForEach-Object { Write-Host "      $_" -ForegroundColor Red }
        $failures++
        continue
    }
    Ok "$p : 0 errors, $warnCount warning(s) repo-wide"

    # Total warning count is noise (16 pre-existing on this base). What matters
    # is whether a warning points at a file THIS diff created or changed.
    foreach ($l in ($lines | Select-String -Pattern ': warning ')) {
        $t = $l.ToString()
        foreach ($f in $added) {
            $leaf = Split-Path $f -Leaf
            if ($t -match [regex]::Escape($leaf)) { $myWarnings += $t.Trim(); break }
        }
    }
}

$myWarnings = @($myWarnings | Sort-Object -Unique)
if ($Incremental) {
    Note "-Incremental: MSBuild may not re-emit warnings, so attribution below is unreliable"
}
if ($myWarnings.Count -gt 0) {
    Note "$($myWarnings.Count) warning(s) in files this change touches:"
    $myWarnings | Select-Object -First 12 | ForEach-Object { Write-Host "      $_" -ForegroundColor Yellow }
}
else { Ok "no warnings attributable to changed files" }

# ---------------------------------------------------------------------------
Section "Tests"
foreach ($tp in @(
        'src\WIT.Data.Access.Tests\WIT.Data.Access.Tests.csproj',
        'src\WIT.AreaServices.Tests\WIT.AreaServices.Tests.csproj')) {
    if (-not (Test-Path $tp)) { continue }
    $out = (& dotnet test $tp --nologo 2>&1 | Out-String)
    $code = $LASTEXITCODE
    $line = ($out -split "`r?`n" | Select-String -Pattern 'Passed!|Failed!|No test source' | Select-Object -First 1)
    if ($code -ne 0) {
        Bad "$tp : $line"
        ($out -split "`r?`n" | Select-String -Pattern 'Failed |Error Message|Assert\.' | Select-Object -First 20) |
            ForEach-Object { Write-Host "      $_" -ForegroundColor Red }
        $failures++
    }
    else { Ok "$tp : $line" }
}

# ---------------------------------------------------------------------------
Section "Stale references"
if ($movedNames.Count -eq 0) { Note "no moved/deleted service files in the diff" }
foreach ($n in $movedNames) {
    $stale = @(& git grep -n --fixed-strings -- $n -- 'src/WIT.AreaServices/*.cs')
    if ($stale.Count -gt 0) {
        Bad "$n still referenced inside WIT.AreaServices:"
        $stale | ForEach-Object { Write-Host "      $_" -ForegroundColor Red }
        $failures++
    }
    else { Ok "$n : no residue in WIT.AreaServices" }
}

# Scoped to the diff on purpose: IssueService and CtsAuthorizationService
# legitimately still use IAreaCallHelper (not yet migrated), so a repo-wide
# grep here is 100% false positives. Verified on TLAWTH-61.
if ($touchedDataAccess.Count -eq 0) { Note "diff touches no WIT.Data.Access source files" }
$leaks = 0
foreach ($f in $touchedDataAccess) {
    if (-not (Test-Path $f)) { continue }
    $hits = @(Select-String -Path $f -Pattern 'IAreaCallHelper|AreaDefnId\.|AreaCallHelper\.ExecuteRequestType')
    if ($hits.Count -gt 0) {
        Bad "legacy Area call surface still in $f :"
        $hits | ForEach-Object { Write-Host "      $($_.LineNumber): $($_.Line.Trim())" -ForegroundColor Red }
        $leaks++
    }
}
if ($leaks -gt 0) { $failures++ }
elseif ($touchedDataAccess.Count -gt 0) { Ok "no Area call surface in the $($touchedDataAccess.Count) touched Data.Access file(s)" }

# ---------------------------------------------------------------------------
Section "Workflow artifacts (must be none)"
$artifacts = @(& git status --porcelain) | Where-Object {
    $_ -match '(?i)(plan|checklist|migration[-_ ]notes|notes|SKILL)\.md$'
}
if ($artifacts.Count -gt 0) {
    Bad "planning/skill artifacts in the working tree - delete before committing:"
    $artifacts | ForEach-Object { Write-Host "      $_" -ForegroundColor Red }
    $failures++
}
else { Ok "no plan/checklist/SKILL.md artifacts" }

# ---------------------------------------------------------------------------
Section "Whitespace + line endings"
# cr-at-eol must be allowed. This repo has NO .gitattributes and a mixed index:
# appsettings.json and some .cs files are stored CRLF (i/crlf), most .cs are
# i/lf. On a CRLF-in-index file every changed line trips a bogus "trailing
# whitespace" because git counts the \r. Verified on appsettings.json.
# Two ranges: committed work (base..HEAD) AND everything not yet committed
# (HEAD vs staged+worktree). Step 4d verifies the version bump BEFORE committing
# it, so checking only the committed range would miss it entirely.
$ws = @()
$ws += (& git -c core.whitespace=cr-at-eol diff --check "$Base...HEAD" 2>&1 | Out-String).Trim()
$ws += (& git -c core.whitespace=cr-at-eol diff --check HEAD 2>&1 | Out-String).Trim()
$ws = @($ws | Where-Object { $_ })
if ($ws.Count -gt 0) { Bad "whitespace errors:"; $ws | ForEach-Object { Write-Host $_ -ForegroundColor Red }; $failures++ }
else { Ok "git diff --check clean, committed + uncommitted (cr-at-eol allowed)" }

# Changing a file's stored EOL is a separate, real problem the check above no
# longer catches, so assert it directly.
$eolChanged = @()
foreach ($f in $added) {
    if (-not (Test-Path $f)) { continue }
    $eol = (& git ls-files --eol -- $f | Out-String).Trim()
    if ($eol -match '^i/(\S+)\s+w/(\S+)') {
        $i = $Matches[1]; $w = $Matches[2]
        if ($i -ne 'none' -and $w -ne 'none' -and $i -ne $w -and $i -ne 'mixed') {
            $eolChanged += "$f  (index=$i worktree=$w)"
        }
    }
}
if ($eolChanged.Count -gt 0) {
    Note "index/worktree EOL mismatch - normal here (core.autocrlf=true), but check the diff is not whole-file:"
    $eolChanged | Select-Object -First 6 | ForEach-Object { Write-Host "      $_" -ForegroundColor Yellow }
}

# A file showing equal large +/- counts is usually a CRLF or BOM accident.
$suspect = @()
foreach ($line in (& git diff --numstat -M "$Base...HEAD")) {
    $parts = $line -split "`t"
    if ($parts.Count -ge 3 -and $parts[0] -match '^\d+$' -and $parts[1] -match '^\d+$') {
        $a = [int]$parts[0]; $d = [int]$parts[1]
        if ($a -gt 30 -and $a -eq $d) { $suspect += "$($parts[2])  (+$a -$d whole-file rewrite?)" }
    }
}
if ($suspect.Count -gt 0) { Note "possible line-ending/BOM churn:"; $suspect | ForEach-Object { Write-Host "      $_" -ForegroundColor Yellow } }
else { Ok "no whole-file rewrites" }

# ---------------------------------------------------------------------------
Section "Change summary (for the PR description)"
Write-Host ""
& git diff --stat -M "$Base...HEAD"
Write-Host ""
$diffLines | ForEach-Object { Write-Host $_ }
Write-Host ""
Write-Host "  uncommitted (what the user still needs to commit):" -ForegroundColor White
$porcelain = (& git status --porcelain | Out-String).TrimEnd()
if ($porcelain) { Write-Host $porcelain } else { Write-Host "    (nothing)" }

# ---------------------------------------------------------------------------
Section "Result"
if ($failures -eq 0) {
    Write-Host "  PASS - 0 blocking issues. Hand back to the user for commit/push." -ForegroundColor Green
    exit 0
}
Write-Host "  FAIL - $failures blocking issue(s). Fix before reporting done." -ForegroundColor Red
exit 1
