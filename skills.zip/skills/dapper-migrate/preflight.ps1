<#
.SYNOPSIS
  Branch setup + migration-surface discovery for a Dapper migration card.

.DESCRIPTION
  Step 1 of the dapper-migrate skill. Does the deterministic, boring part:
    - verifies gh auth + clean working tree (hard fail otherwise)
    - fetches origin, checks out the base branch, fast-forwards it
    - creates (or reuses) the card branch from that base
    - prints the migration surface for the named service so the agent
      does not have to rediscover it

  Never commits, never pushes, never edits source.

  Windows PowerShell 5.1 compatible (no pwsh on the CTS dev boxes).

.PARAMETER Card
  Card number, used verbatim as the branch name. e.g. TLAWTH-63

.PARAMETER Service
  Service class name being migrated. e.g. ManageFollowupReasonService
  Optional - omit to do branch setup only.

.PARAMETER Base
  Base branch. Defaults to the Dapper release integration branch.

.EXAMPLE
  powershell -File .claude/skills/dapper-migrate/preflight.ps1 -Card TLAWTH-63 -Service ManageFollowupReasonService
#>
param(
    [Parameter(Mandatory = $true)][string]$Card,
    [string]$Service,
    [string]$Base = 'Release-TLAWTH-36-Replace-Discovery-Dapper'
)

# Deliberately NOT 'Stop': git and gh write progress to stderr, and under
# Stop + 2>&1 PowerShell 5.1 turns that into a terminating NativeCommandError
# even on exit code 0. Exit codes are checked explicitly instead.
$ErrorActionPreference = 'Continue'

function Fail($msg) { Write-Host ""; Write-Host "FAIL: $msg" -ForegroundColor Red; exit 1 }
function Section($msg) { Write-Host ""; Write-Host "== $msg ==" -ForegroundColor Cyan }
function Ok($msg) { Write-Host "  ok  $msg" -ForegroundColor Green }
function Note($msg) { Write-Host "  !!  $msg" -ForegroundColor Yellow }

# Run a native command, capture merged output, return exit code.
function Run {
    param([string]$Exe, [string[]]$Arguments)
    $script:RunOut = (& $Exe @Arguments 2>&1 | Out-String)
    return $LASTEXITCODE
}

# Git Credential Manager is the configured helper on these boxes and it needs a
# UI/VS Code pipe to answer. From a non-interactive shell it dies with
# "Cannot prompt because user interactivity has been disabled". Route network
# git operations through gh's credential helper instead, per-invocation, so no
# global git config is mutated.
$GhCred = @('-c', 'credential.helper=', '-c', 'credential.helper=!gh auth git-credential')

$root = (& git rev-parse --show-toplevel 2>$null)
if ($LASTEXITCODE -ne 0 -or -not $root) { Fail "not inside a git repository" }
Set-Location ($root -replace '/', '\')

Section "Preflight"

# gh supplies the https credential helper that git fetch/pull/push use here.
if ((Run git @('rev-parse', '--git-dir')) -ne 0) { Fail "git is broken here" }
if ((Run gh @('auth', 'status')) -ne 0) { Fail "gh not authenticated. Run: gh auth login`n$RunOut" }
$m = [regex]::Match($RunOut, 'account (\S+)')
Ok ("gh authenticated" + $(if ($m.Success) { " as $($m.Groups[1].Value)" } else { "" }))

if ((Run gh @('repo', 'view', '--json', 'nameWithOwner', '-q', '.nameWithOwner')) -ne 0) {
    Fail "gh repo view failed - is origin a GitHub remote?`n$RunOut"
}
Ok "repo $($RunOut.Trim())"

# A dirty tree means the migration diff would get mixed with unrelated work.
$dirty = (& git status --porcelain | Out-String).Trim()
if ($dirty) { Write-Host $dirty; Fail "working tree not clean. Commit, stash, or discard first." }
Ok "working tree clean"

Section "Branch setup"

if ((Run git ($GhCred + @('fetch', 'origin', '--prune'))) -ne 0) { Fail "git fetch origin failed`n$RunOut" }
Ok "fetched origin"

if ((Run git @('rev-parse', '--verify', '--quiet', "refs/remotes/origin/$Base")) -ne 0) {
    Fail "origin/$Base does not exist"
}
if ((Run git @('checkout', $Base)) -ne 0) { Fail "could not checkout $Base`n$RunOut" }
if ((Run git @('merge', '--ff-only', "origin/$Base")) -ne 0) {
    Fail "$Base cannot fast-forward to origin/$Base - it has diverged. Resolve manually.`n$RunOut"
}
$baseSha = (& git rev-parse --short HEAD).Trim()
Ok "$Base up to date at $baseSha"

$existsLocal = (& git rev-parse --verify --quiet "refs/heads/$Card")
if ($existsLocal) {
    if ((Run git @('checkout', $Card)) -ne 0) { Fail "could not checkout existing branch $Card`n$RunOut" }
    $behind = [int](& git rev-list --count "$Card..$Base").Trim()
    Ok "reused existing branch $Card"
    if ($behind -gt 0) { Note "$Card is behind $Base by $behind commit(s) - rebase before continuing" }
}
else {
    if ((Run git @('checkout', '-b', $Card, $Base)) -ne 0) { Fail "could not create $Card from $Base`n$RunOut" }
    Ok "created branch $Card from $Base ($baseSha)"
}
Write-Host ""
Write-Host "  HEAD -> $((& git rev-parse --abbrev-ref HEAD).Trim())" -ForegroundColor White

if (-not $Service) {
    Write-Host ""
    Note "no -Service given; skipping surface discovery"
    exit 0
}

# ---------------------------------------------------------------------------
# Migration surface
# ---------------------------------------------------------------------------
$iface = "I$Service"
$areaIds = @()

Section "Source files"
$srcFiles = @(& git ls-files "src/**/$Service.cs" "src/**/$iface.cs" "src/**/$Service*Tests.cs")
if ($srcFiles.Count -eq 0) { Note "no files matched '$Service' - check the spelling of -Service" }
$srcFiles | ForEach-Object { Write-Host "  $_" }

Section "Legacy call surface"
$impl = $srcFiles | Where-Object { $_ -match "/$([regex]::Escape($Service))\.cs$" } | Select-Object -First 1
if ($impl) {
    $body = Get-Content $impl -Raw
    $helpers = [regex]::Matches($body, '_(?:areaCallHelper|apiHelper|dapperHelper)\.(\w+)') |
        ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique
    Write-Host "  helper methods called: $($helpers -join ', ')"

    $ctorDeps = [regex]::Match($body, "public\s+$([regex]::Escape($Service))\s*\(([^)]*)\)")
    if ($ctorDeps.Success) { Write-Host "  ctor deps: $($ctorDeps.Groups[1].Value -replace '\s+', ' ')" }

    $areaIds = @([regex]::Matches($body, 'AreaDefnId\.(\w+)') |
        ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
    if ($areaIds.Count -gt 0) {
        Write-Host "  AreaDefnId entries used:"
        foreach ($id in $areaIds) {
            $hit = Select-String -Path 'src/WIT.UI.Classes/Enums/AreaDefnId.cs' -Pattern "^\s*$id\s*=\s*(\d+)" |
                Select-Object -First 1
            $num = if ($hit) { $hit.Matches[0].Groups[1].Value } else { '?' }
            Write-Host "    $id = $num"
        }
    }
}
else { Note "implementation file not found" }

Section "Candidate CtsStoredProcedures entries"
$enumFile = 'src/WIT.UI.Classes/Enums/DapperHelperEnums.cs'
$enumLines = Get-Content $enumFile
foreach ($id in $areaIds) {
    $found = $false
    for ($i = 0; $i -lt $enumLines.Count; $i++) {
        # AreaDefnId.GetFooByBar -> CtsStoredProcedures.getFooByBar (case differs)
        if ($enumLines[$i] -match "^\s*$([regex]::Escape($id))\s*,\s*$") {
            $attr = if ($i -gt 0 -and $enumLines[$i - 1] -match '\[StoredProcedureInfo\((.*)\)\]') {
                $Matches[1]
            }
            else { 'NO [StoredProcedureInfo] ATTRIBUTE -> defaults apply, confirm schema' }
            Write-Host ("  {0,-42} {1}   (line {2})" -f $enumLines[$i].Trim().TrimEnd(','), $attr, ($i + 1))
            $found = $true
        }
    }
    if (-not $found) { Note "$id -> no matching proc entry. Stop and confirm with the user before inventing one." }
}

Section "Consumers of $iface"
$consumers = @(& git grep -n --fixed-strings -- $iface -- 'src/*.cs' 'src/*.cshtml') |
    Where-Object { $_ -notmatch "/$iface\.cs:" -and $_ -notmatch "/$([regex]::Escape($Service))\.cs:" }
if ($consumers.Count -eq 0) { Note "no consumers found - verify by hand" }
$consumers | ForEach-Object { Write-Host "  $_" }

Section "Reference migrations already on $Base"
Write-Host "  TLAWTH-61  ManageContactSourceService  valMerge + merge + IDistributedCache  (closest to a CRUD admin service)"
Write-Host "  TLAWTH-60  LetterService               read-only, five procs"
Write-Host "  git show TLAWTH-61:src/WIT.Data.Access/Services/ManageContactSourceService.cs"
Write-Host "  git diff $Base...TLAWTH-61 --stat"

Section "Next"
Write-Host "  1. Read .claude/skills/dapper-migrate/reference.md, then migrate."
Write-Host "  2. powershell -File .claude/skills/dapper-migrate/verify.ps1"
Write-Host "  3. Report the PR summary. Do NOT commit or push - the user does that."
Write-Host ""
