# CTS Dapper migration — verified conventions

Everything here was read out of the repo at
`Release-TLAWTH-36-Replace-Discovery-Dapper @ a220012`, not inferred. Re-check
before trusting if the base has moved a long way.

## Layout

| Thing | Path |
|---|---|
| Solution | `src/WIT_CTS.sln` |
| Legacy layer (source) | `src/WIT.AreaServices/Services/` + `Services/Interfaces/` |
| Dapper layer (target) | `src/WIT.Data.Access/Services/` + `Services/Interfaces/` |
| Target namespace | `WIT.CTS.Data.Access.Services` / `...Services.Interfaces` |
| Target csproj | `src/WIT.Data.Access/WIT.CTS.Data.Access.csproj` (note: filename ≠ folder name) |
| Tests for migrated services | `src/WIT.Data.Access.Tests/Services/<Service>Tests.cs` |
| Tests namespace | `WIT.Data.Access.Tests.Services` (note: **no** `.CTS.`, unlike the product namespace) |
| DI | `src/WIT.UI.MVC/WitDependencyInjection.cs` |
| Proc enum | `src/WIT.UI.Classes/Enums/DapperHelperEnums.cs` |
| Legacy area enum | `src/WIT.UI.Classes/Enums/AreaDefnId.cs` |
| `AreaValidationResult` | `src/WIT.DomainModels/MiscDomainModels.cs` (`IsValid`, `ErrorMessage`) |

`IDapperHelper<T>` comes from the NuGet package
`Aetna.WIT-Development.Infrastructure.DapperHelper` (namespace
`WIT.Dapper.Helper.Interfaces`) — it is not repo source, so you cannot read the
signatures. Copy call shapes from a neighbouring migrated service instead.

## Methods in use on `IDapperHelper<CtsStoredProcedures>`

```
LoadIEnumerableData<T>(proc)              LoadIEnumerableData<T>(proc, parameters)
LoadScalarData<T>(proc, parameters)       LoadScalarDataAsync<T>(proc, parameters)
ExecuteStoredProcedure(proc, parameters) -> int   (affected rows)
ExecuteStoredProcedureAsync(proc, parameters) -> Task<int>
```

There is also `ICachedDapperHelper<CtsCacheKeys, CtsStoredProcedures>` with
`ClearCache(key)` — see `SystemMessageService`.

## Legacy → Dapper call translation

| Legacy `IAreaCallHelper` | Dapper |
|---|---|
| `MapToIEnumerable<T>(AreaDefnId.X)` | `LoadIEnumerableData<T>(CtsStoredProcedures.x)` |
| `MapToScaler<TReq,T>(AreaDefnId.X, req)` | `LoadScalarData<T>(CtsStoredProcedures.x, req)` |
| `ExecuteRequest(ExecuteRequestType.Update, AreaDefnId.X, req)` | `ExecuteStoredProcedure(CtsStoredProcedures.x, req) > 0` |
| `IsAreaRequestParameterObjectValid(AreaDefnId.ValX, req, out msg)` | `LoadScalarData<AreaValidationResult>(CtsStoredProcedures.valX, req)` |

`AreaDefnId` entries are PascalCase; `CtsStoredProcedures` entries are the same
name in camelCase. `preflight.ps1` resolves the mapping and prints each entry's
`[StoredProcedureInfo(...)]` schema. **If an entry has no match, stop and ask** —
do not add a proc enum entry on your own initiative.

## The validate-then-merge shape (verified, TLAWTH-61)

This is the pattern for every `Manage*Service.AddUpdate*(request, out string errorMessage)`:

```csharp
public bool AddUpdateContactSources(ContactSourceDomainModels.CTSmergeContactSourceUpdateRequest request, out string errorMessage)
{
    var validationResult = _dapperHelper.LoadScalarData<AreaValidationResult>(
        CtsStoredProcedures.valMergeContactSource,
        request.MapToObject<ContactSourceDomainModels.CTSvalMergeContactSourceValidateRequest>());

    errorMessage = validationResult?.ErrorMessage;

    var isSuccess = validationResult != null && validationResult.IsValid &&
                    _dapperHelper.ExecuteStoredProcedure(CtsStoredProcedures.mergeContactSource, request) > 0;

    if (isSuccess)
    {
        _distributedCache.Remove(CacheKeys.Dropdowns.AllContactSources);
    }

    return isSuccess;
}
```

Note the short-circuit: when validation fails the merge proc must **not** run.
`request.MapToObject<T>()` is `WIT.UI.Classes.Extensions`.

This exact code emits two nullable warnings (`CS8604` on the `MapToObject`
argument, `CS8601` on the `errorMessage` assignment) because `WIT.Data.Access`
has `<Nullable>enable</Nullable>` while the domain models do not. The reference
migration shipped with them. Match the reference rather than inventing
suppressions, and call the two warnings out in your summary so the reviewer
knows they are expected.

## Read-only service shape (verified, TLAWTH-60)

Constructor-injected field, one call per method, no ceremony:

```csharp
public class LetterService : ILetterService
{
    private readonly IDapperHelper<CtsStoredProcedures> _dapperHelper;

    public LetterService(IDapperHelper<CtsStoredProcedures> dapperHelper) => _dapperHelper = dapperHelper;

    public IEnumerable<LettersDomainModels.LetterInfo> GetLetterInfoList(LettersDomainModels.LetterClaimLetterListRetrieveRequest request)
        => _dapperHelper.LoadIEnumerableData<LettersDomainModels.LetterInfo>(CtsStoredProcedures.getLetterListByClaimNum, request);
}
```

`SystemMessageService` uses a primary constructor instead. Either is accepted;
follow whichever neighbour you are copying.

## Interface placement

The interface **moves with the implementation** into
`src/WIT.Data.Access/Services/Interfaces/` under namespace
`WIT.CTS.Data.Access.Services.Interfaces`. Keep the name and signatures byte-identical.

Use `git mv` (or make sure the change lands as a rename) so the diff shows
`R0xx` rather than delete+add — the reference commits all do.

## Test file shape

Global usings in `src/WIT.Data.Access.Tests/GlobalUsings.cs` already provide
`Moq`, `Autofac.Extras.Moq`, `WIT.Dapper.Helper.Interfaces`, `WIT.DomainModels`,
`WIT.UI.Classes.Core`, `WIT.UI.Classes.Enums`, `WIT.CTS.Data.Access.Services`.
So a test file only needs its own domain-model namespace plus:

```csharp
using Xunit;
using Assert = Xunit.Assert;   // REQUIRED: the csproj references BOTH MSTest.TestFramework
                               // and (transitively, via WIT.UI.Classes) xunit, so bare
                               // `Assert` is ambiguous and will not compile.
```

Derive from `WitUnitTestBaseClass<TSut>` (`src/WIT.UI.Classes/Core/`), which gives
`SystemUnderTest` and `CreateSystemUnderTest(autoMock)`. Shape:

```csharp
public class ManageContactSourceServiceTests : WitUnitTestBaseClass<ManageContactSourceService>
{
    [Fact]
    public void GetContactSourceList_returns_data_from_expected_stored_procedure()
    {
        using var autoMock = AutoMock.GetLoose();
        var expected = new List<...> { new() { ContactSourceID = 1 } };

        autoMock.Mock<IDapperHelper<CtsStoredProcedures>>()
            .Setup(x => x.LoadIEnumerableData<...>(CtsStoredProcedures.getContactSourcesByContactSourceId))
            .Returns(expected);

        CreateSystemUnderTest(autoMock);

        var result = SystemUnderTest.GetContactSourceList();

        autoMock.Mock<IDapperHelper<CtsStoredProcedures>>()
            .Verify(x => x.LoadIEnumerableData<...>(CtsStoredProcedures.getContactSourcesByContactSourceId), Times.Once);
        Assert.Same(expected, result);
    }
}
```

Cover, at minimum, one test per public method, plus for a validate-then-merge method:

1. validation fails → returns `false`, `errorMessage` propagated, merge proc `Times.Never`, cache `Times.Never`
2. validation passes but merge returns `0` → returns `false`, cache `Times.Never`
3. validation passes and merge returns `1` → returns `true`, cache cleared `Times.Once`

Mock the request-object argument with `It.IsAny<object>()` for the `valMerge` call
(the service passes a *mapped* object, not the original `request`, so a
reference-equality setup will not match). Use the original `request` for the
merge call, which does pass it straight through.

## Wiring — usually a no-op

`WitDependencyInjection.cs` already imports both `WIT.AreaServices.Services` and
`WIT.CTS.Data.Access.Services` (+ `.Interfaces`). Once the old type is deleted,
`services.AddTransient<IFooService, FooService>();` resolves to the moved types
with **no edit at all** — TLAWTH-60 and TLAWTH-61 both left the DI file untouched.

Do not manufacture a no-op DI diff. Do check for ambiguity: that file already
carries aliases for exactly this reason —

```csharp
using ISubClientSearchService = WIT.CTS.Data.Access.Services.Interfaces.ISubClientSearchService;
using SubClientSearchService  = WIT.CTS.Data.Access.Services.SubClientSearchService;
```

— which are needed only while a same-named type still exists in both layers. If
you fully delete the legacy type you should not need a new alias.

Consumers (controllers) typically need one added `using
WIT.CTS.Data.Access.Services.Interfaces;` and nothing else.

## App version

Single source: `src/WIT.UI.MVC/appsettings.json` → `CtsAppConfig.AppVersionString`
(line 6). The `.Dev` / `.QA*` / `.Prod` / `.Localhost` variants do **not** carry it.
It surfaces via `CtsApplicationConfiguration.AppVersionString` →
`WitBaseController.SetupGlobalViewData` → the version tooltip in `_Layout.cshtml`.

Format `yy.m.dd.<pr>` — two-digit year, month and day **unpadded**, then the
number of the PR carrying the change. From history:

```
26.5.22.35   26.6.30.43   26.7.6.48   26.7.7.60   26.8.5.75   26.8.12.76   26.8.14.82
```

The last component is the PR's own number, set in a commit *inside* that PR —
verified: commit `462a29d "Update appsettings.json"` set `26.8.14.82` and was part
of PR **#82** (branch `TLAWTH-59`). Hence the draft-PR-first ordering: you cannot
know the number until the PR exists.

Two caveats worth knowing:

- Not every card PR has bumped it. TLAWTH-61 shipped as PR #87 without a bump,
  which is why this step is now explicit in the skill.
- The bump is conventionally its own commit, separate from the migration commit.

`appversion.ps1` handles the format, the `gh` lookup, and the encoding. Do not
hand-edit: the file is UTF-8 **without BOM** and all-CRLF, and PowerShell's
`Set-Content -Encoding utf8` writes a BOM, which turns a one-line bump into a
whole-file diff.

## Non-obvious traps

- **A service may have no controller.** `ManageFollowupReasonService` is
  referenced only by `WitDependencyInjection.cs` (plus unrelated view models in
  `src/WIT.UI.MVC/Models/FollowupReason/`). An empty consumer list is a real
  answer, not a failed search — don't invent a consumer.
- **`git fetch/pull/push` fails from a non-interactive shell.** The configured
  credential helper is Git Credential Manager, which tries a VS Code pipe
  (`\\.\pipe\vscode-git-*-sock`) and then dies with *"Cannot prompt because user
  interactivity has been disabled"*. `preflight.ps1` works around it per-command
  with `git -c credential.helper= -c 'credential.helper=!gh auth git-credential' fetch`.
  Use that same prefix for any other network git command.
- **`dotnet build` without `--no-incremental` re-reports zero warnings** on an
  already-built project, so warning checks silently pass. `verify.ps1` forces
  `--no-incremental`.
- **`WIT.CTS.Data.Access.csproj` already references `WIT.AreaServices.csproj`**,
  so a migrated service can still see legacy types. That makes leftover
  `IAreaCallHelper` usage compile fine — `verify.ps1` greps the touched files for
  it because the compiler will not complain.
- **`IssueService` and `CtsAuthorizationService` still use `IAreaCallHelper`
  inside `WIT.Data.Access`.** They are not yet migrated. Any repo-wide "no Area
  helper in Data.Access" check is all false positives; scope to the diff.
- **`git diff --check` lies on CRLF-in-index files.** There is no
  `.gitattributes`, `core.autocrlf=true`, and the index is mixed:
  `git ls-files --eol` reports `i/crlf` for `appsettings.json` and e.g.
  `AttachmentService.cs`, but `i/lf` for most `.cs`. On an `i/crlf` file git
  counts the `\r` as trailing whitespace on every changed line, so a clean
  one-line edit reports `trailing whitespace` and exits 2. Use
  `git -c core.whitespace=cr-at-eol diff --check`. This is why TLAWTH-61 passed
  the naive check (its files were `i/lf`) while a version bump does not.
- Baseline on the base branch: `WIT.Data.Access.Tests` builds with **16
  warnings / 0 errors**, and tests are **44 passing** (Data.Access) + **17
  passing** (AreaServices). Anything worse is yours.
