<#
.SYNOPSIS
  Set AppVersionString to yy.m.dd.<pr> in src/WIT.UI.MVC/appsettings.json.

.DESCRIPTION
  Step 4 of the dapper-migrate skill. The last component is the number of the PR
  carrying the change, so the PR must already exist (open it as a draft first) -
  hence -PrNumber, or resolution from the current branch via gh.

  Format is verified against repo history: two-digit year, then month and day
  with NO zero padding, then the PR number.
      26.8.5.75   = 2026-08-05, PR #75
      26.8.14.82  = 2026-08-14, PR #82  (set inside PR #82 itself, branch TLAWTH-59)

  Edits exactly one line. Writes UTF-8 with no BOM and preserves CRLF, because
  appsettings.json has no BOM and is all-CRLF - a naive Set-Content would add a
  BOM and show up as a whole-file rewrite in the diff.

  Never commits, never pushes.

.PARAMETER PrNumber
  PR number to use. Omit to resolve it from the current branch with gh.

.PARAMETER DryRun
  Print the computed version and leave the file alone.

.EXAMPLE
  powershell -File .claude/skills/dapper-migrate/appversion.ps1 -DryRun
  powershell -File .claude/skills/dapper-migrate/appversion.ps1 -PrNumber 91
#>
param(
    [int]$PrNumber = 0,
    [string]$File = 'src/WIT.UI.MVC/appsettings.json',
    [switch]$DryRun
)

$ErrorActionPreference = 'Continue'

function Fail($msg) { Write-Host "FAIL: $msg" -ForegroundColor Red; exit 1 }
function Ok($msg) { Write-Host "  ok  $msg" -ForegroundColor Green }
function Note($msg) { Write-Host "  !!  $msg" -ForegroundColor Yellow }

$root = (& git rev-parse --show-toplevel 2>$null)
if ($LASTEXITCODE -ne 0 -or -not $root) { Fail "not inside a git repository" }
Set-Location ($root -replace '/', '\')

if (-not (Test-Path $File)) { Fail "$File not found" }

$branch = (& git rev-parse --abbrev-ref HEAD).Trim()

# ---------------------------------------------------------------------------
# PR number
# ---------------------------------------------------------------------------
if ($PrNumber -le 0) {
    $json = (& gh pr view $branch --json number,isDraft,url 2>&1 | Out-String)
    if ($LASTEXITCODE -ne 0) {
        Fail @"
no PR found for branch '$branch', and -PrNumber was not supplied.

The version's last component IS the PR number, so the PR has to exist first.
Push the branch and open a DRAFT PR, then re-run:

  git push -u origin $branch
  gh pr create --draft --base Release-TLAWTH-36-Replace-Discovery-Dapper --head $branch --title "<title>" --body-file <file>

gh said:
$json
"@
    }
    try { $meta = $json | ConvertFrom-Json } catch { Fail "could not parse gh output:`n$json" }
    $PrNumber = [int]$meta.number
    Ok "resolved PR #$PrNumber for branch $branch  (draft=$($meta.isDraft))"
    if (-not $meta.isDraft) { Note "PR #$PrNumber is NOT a draft - confirm the user wanted it open for review already" }
    Write-Host "      $($meta.url)"
}
else {
    Ok "using supplied PR #$PrNumber"
}

# ---------------------------------------------------------------------------
# Version string - month and day are NOT zero padded (verified: 26.8.5.75)
# ---------------------------------------------------------------------------
$now = Get-Date
$version = '{0}.{1}.{2}.{3}' -f $now.ToString('yy'), $now.Month, $now.Day, $PrNumber

# ---------------------------------------------------------------------------
# Edit exactly one line, byte-preserving otherwise
# ---------------------------------------------------------------------------
$raw = [IO.File]::ReadAllText($File)
$pattern = '("AppVersionString"\s*:\s*")([^"]*)(")'
$m = [regex]::Match($raw, $pattern)
if (-not $m.Success) { Fail "AppVersionString not found in $File" }
if ([regex]::Matches($raw, $pattern).Count -gt 1) { Fail "AppVersionString appears more than once in $File" }

$old = $m.Groups[2].Value
Write-Host "  $old  ->  $version" -ForegroundColor White

if ($old -eq $version) {
    Ok "already at $version - nothing to do"
    exit 0
}

if ($DryRun) { Note "-DryRun: file not modified"; exit 0 }

$updated = [regex]::Replace($raw, $pattern, { param($x) $x.Groups[1].Value + $version + $x.Groups[3].Value }, 1)

# UTF-8 *without* BOM; ReadAllText/WriteAllText round-trip keeps the CRLFs.
[IO.File]::WriteAllText($File, $updated, (New-Object System.Text.UTF8Encoding($false)))
Ok "wrote $File"

# ---------------------------------------------------------------------------
# Prove the edit is one line and nothing else moved
# ---------------------------------------------------------------------------
$numstat = (& git diff --numstat -- $File | Out-String).Trim()
if ($numstat) {
    $parts = $numstat -split "`t"
    if ($parts[0] -eq '1' -and $parts[1] -eq '1') { Ok "diff is +1 -1 as expected" }
    else { Note "unexpected diff shape ($($parts[0]) added / $($parts[1]) removed) - inspect before committing"; }
}
else { Note "git reports no change to $File" }

$check = (& git diff --check -- $File | Out-String).Trim()
if ($check) { Note "whitespace warnings:`n$check" }

Write-Host ""
Write-Host "  Next: commit the bump on top of the migration commit, e.g." -ForegroundColor White
Write-Host "    git add $File"
Write-Host "    git commit -m `"chore(version): bump AppVersionString to $version`""
Write-Host "    git push"
Write-Host ""
Write-Host "  VERSION=$version" -ForegroundColor Cyan
