---
name: dapper-migrate
description: 'Run a CTS Dapper migration card end to end: check out and fast-forward the Dapper release base branch with the gh CLI, cut the card branch (e.g. TLAWTH-63), migrate the named service from WIT.AreaServices to WIT.Data.Access with IDapperHelper, add tests, build and verify, open a DRAFT PR, bump AppVersionString to yy.m.dd.<pr>, and hand back a commit/PR-ready summary. Use for "migrate X to Dapper", "TLAWTH-nn <Service> to Dapper Service", replacing IAreaCallHelper/AreaDefnId with stored-procedure calls, starting a Dapper migration branch, or bumping the app version.'
argument-hint: '<CARD> <Service> to Dapper Service — e.g. TLAWTH-63 ManageFollowupReasonService to Dapper Service'
user-invocable: true
---

# CTS Dapper Service Migration

Input is a card number plus a target, e.g. `TLAWTH-63 ManageFollowupReasonService to Dapper Service`.

**preflight** (scripted) → **migrate** (you) → **verify** (scripted) → **draft PR + version bump** (scripted) → **report**.

You do commit and push, and you open the PR **as a draft**. You never mark it
ready for review — that is the user's gate. Do not run `gh pr ready`, do not
merge, and do not push to the base branch.

Paths are relative to the repo root. `SKILL_DIR` = `%USERPROFILE%\.claude\skills\dapper-migrate`.

Windows PowerShell 5.1 only — there is no `pwsh` here. Use `powershell -NoProfile -File`.

## 1. Preflight — branch setup + discovery

```powershell
powershell -NoProfile -File "$env:USERPROFILE\.claude\skills\dapper-migrate\preflight.ps1" -Card TLAWTH-63 -Service ManageFollowupReasonService
```

Verifies `gh` auth and a clean tree, fetches origin, fast-forwards
`Release-TLAWTH-36-Replace-Discovery-Dapper`, creates `TLAWTH-63` from it, then
prints the migration surface: source files, helper methods and `AreaDefnId`
entries in use, the matching `CtsStoredProcedures` entries **with their
`[StoredProcedureInfo]` schema**, and every consumer of the interface.

Exits non-zero and changes nothing if the tree is dirty, the base has diverged,
or `gh` is not logged in. Fix the cause; do not work around it. `-Base <branch>`
overrides the base; omit `-Service` for branch setup only. If the card branch
already exists and is behind the base, rebase before editing.

## 2. Migrate

Read `SKILL_DIR/reference.md` first — verified layer paths, namespaces, the
legacy→Dapper translation table, the validate-then-merge shape, the test-file
shape, and the traps. Then:

1. Move the implementation to `src/WIT.Data.Access/Services/` (namespace
   `WIT.CTS.Data.Access.Services`) and the interface to `.../Services/Interfaces/`.
   Land them as renames so the diff reads `R0xx`.
2. Replace every `IAreaCallHelper` call with the `IDapperHelper<CtsStoredProcedures>`
   equivalent, using the proc entries preflight resolved. Preserve the public
   contract, parameter mapping, and return semantics exactly.
3. Delete the legacy implementation.
4. Update consumers — usually one added `using`. Leave `WitDependencyInjection.cs`
   alone unless it genuinely no longer compiles.
5. Add `src/WIT.Data.Access.Tests/Services/<Service>Tests.cs`.

Hard rules:

- Preserve the public contract unless the user explicitly asked to change it.
- Never invent a `CtsStoredProcedures` entry, schema, or parameter mapping. If
  preflight found no match, stop and ask.
- Do not touch database objects, logging payloads, or unrelated services.
- Do not create plan files, checklists, `NOTES.md`, or copies of this skill in
  the repo. Plan in the conversation. Write the PR body to `$env:TEMP`, never
  into the working tree. `verify.ps1` fails the run if it finds such files.
- Do not discard or overwrite unrelated working-tree changes.

Ambiguous request → say so and ask before editing. Unambiguous → state your
hypothesis in one line and proceed.

## 3. Verify

```powershell
powershell -NoProfile -File "$env:USERPROFILE\.claude\skills\dapper-migrate\verify.ps1"
```

Builds `WIT.Data.Access.Tests` and `WIT.UI.MVC` with `--no-incremental`, runs
both test projects, attributes warnings to files *this* diff touched, greps for
stale legacy references, checks for workflow artifacts and EOL churn, and prints
the diff facts. ~90s; `-SkipMvc` (~45s) while iterating, full run before reporting.

Exit 0 = proceed. Non-zero = fix and re-run; do not proceed to step 4.

Baseline on the base branch: 0 errors, 16 warnings, 44 passing (Data.Access) +
17 passing (AreaServices).

## 4. Draft PR, then version bump

`AppVersionString` is `yy.m.dd.<pr>` — the last component is **this PR's own
number**, so the PR must exist before the version can be written. That is why
the draft PR comes first. Verified: PR #82 (branch TLAWTH-59) set
`26.8.14.82` in its own commit `462a29d`.

**4a — commit and push the migration:**

```powershell
git add -A
git commit -m "feat(dapper): migrate ManageFollowupReasonService to Dapper data access (TLAWTH-63)"
git push -u origin TLAWTH-63
```

If `push` fails with *"Cannot prompt because user interactivity has been
disabled"*, use the gh credential helper (see Gotchas).

**4b — open the DRAFT PR.** Write the body from step 5 to a temp file *outside*
the repo:

```powershell
$body = "$env:TEMP\TLAWTH-63-pr.md"   # NOT in the working tree
gh pr create --draft --base Release-TLAWTH-36-Replace-Discovery-Dapper --head TLAWTH-63 --title "feat(dapper): migrate ManageFollowupReasonService to Dapper data access (TLAWTH-63)" --body-file $body
```

Add `--dry-run` first if you want to see what would be created without creating it.

**4c — bump the version:**

```powershell
powershell -NoProfile -File "$env:USERPROFILE\.claude\skills\dapper-migrate\appversion.ps1"
```

Resolves the PR number from the current branch via `gh`, computes `yy.m.dd.<pr>`
(month and day **not** zero-padded — `26.8.5.75`, not `26.08.05.75`), and rewrites
the one line in `src/WIT.UI.MVC/appsettings.json`, preserving UTF-8-no-BOM and
CRLF. It asserts the diff is exactly +1/-1. `-PrNumber <n>` to override,
`-DryRun` to preview. It warns if the PR is not a draft.

**4d — re-verify, then commit the bump:**

```powershell
powershell -NoProfile -File "$env:USERPROFILE\.claude\skills\dapper-migrate\verify.ps1" -SkipMvc
git add src/WIT.UI.MVC/appsettings.json
git commit -m "chore(version): bump AppVersionString to <version>"
git push
```

Keep the bump as its own commit — that is how the repo has always done it
(`462a29d Update appsettings.json`).

Then update the draft PR body with the final version and counts:

```powershell
gh pr edit <pr> --body-file $body
```

## 5. Report

Print the block below and stop. State that the PR is **a draft**, give its URL,
and say the user needs to review and mark it ready.

Subject line = commit message; body = PR description.

```
feat(dapper): migrate <Service> to Dapper data access (<CARD>)

Moves <Service> from WIT.AreaServices to WIT.Data.Access and replaces its
IAreaCallHelper calls with IDapperHelper<CtsStoredProcedures>. Public contract
unchanged.

## Changes
- Moved `I<Service>` -> `src/WIT.Data.Access/Services/Interfaces/` (`WIT.CTS.Data.Access.Services.Interfaces`)
- Moved `<Service>` -> `src/WIT.Data.Access/Services/` (`WIT.CTS.Data.Access.Services`)
- Deleted the legacy `src/WIT.AreaServices/Services/<Service>.cs`
- <consumer changes, or "No consumer changes required">
- <DI changes, or "No DI changes required — WitDependencyInjection.cs already imports both namespaces">
- Bumped `AppVersionString` to `<yy.m.dd.pr>`

## Stored procedure mapping
| Method | Was (AreaDefnId) | Now (CtsStoredProcedures) | Schema |
|---|---|---|---|
| `GetX()` | `GetX` (14187) | `getX` | CTS |
```

Keep the PR body to just the intro paragraph, Changes, and Stored procedure
mapping. Do not add Behavior, Tests, Verification, or Notes/risks sections —
that detail belongs in your report to the user in chat, not the PR description.

Fill every placeholder from real output. Do not leave a `<...>` in what you hand
over. Then tell the user the one command you deliberately did not run:

```powershell
gh pr ready <pr>
```

## Gotchas

- **`git fetch`/`push` fails from a non-interactive shell.** Git Credential
  Manager tries a VS Code pipe and dies with *"Cannot prompt because user
  interactivity has been disabled"*. Prefix network git commands with
  `-c credential.helper= -c 'credential.helper=!gh auth git-credential'`:
  ```powershell
  git -c credential.helper= -c 'credential.helper=!gh auth git-credential' push -u origin TLAWTH-63
  ```
  `preflight.ps1` already does this for `fetch`.
- **The version's last component is the PR number, not a build counter.** You
  cannot compute it before the PR exists. Draft PR first, always.
- **Month and day are not zero-padded.** `26.8.5.75`. Only `appsettings.json`
  carries `AppVersionString` — the `.Dev/.QA/.Prod/.Localhost` variants do not.
- **`appsettings.json` is UTF-8 with no BOM and all-CRLF.** `Set-Content -Encoding utf8`
  adds a BOM and turns the bump into a whole-file diff. `appversion.ps1` uses
  `[IO.File]::WriteAllText` with `UTF8Encoding($false)`.
- **`git diff --check` false-positives on CRLF-in-index files.** No
  `.gitattributes` exists and the index is mixed (`appsettings.json` and some
  `.cs` are `i/crlf`, most `.cs` are `i/lf`), so git counts the `\r` as trailing
  whitespace on every changed line. Use
  `git -c core.whitespace=cr-at-eol diff --check`. `verify.ps1` does.
- **Test files need `using Assert = Xunit.Assert;`.** The test csproj references
  MSTest *and* xunit (transitively), so bare `Assert` is ambiguous.
- **The target csproj is `WIT.CTS.Data.Access.csproj` inside `src/WIT.Data.Access/`** —
  filename and folder disagree.
- **Test namespace is `WIT.Data.Access.Tests.Services`** — no `.CTS.`, unlike the
  product namespace `WIT.CTS.Data.Access.Services`.
- **`WIT.Data.Access` references `WIT.AreaServices`**, so leftover legacy calls
  still compile. Only the `verify.ps1` grep catches them.
- **A migrated service may have no controller.** DI registration alone is a
  legitimate full consumer list.
- **Splatting into native commands breaks in PS 5.1** (`MSB1001: Unknown switch`).
  Build an array and pass it positionally: `& dotnet $argv`.

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `FAIL: working tree not clean` | Commit, stash, or discard first. Preflight refuses so the migration diff stays clean. |
| `FAIL: ... cannot fast-forward to origin/...` | Base branch diverged locally. Resolve by hand, then re-run. |
| `fatal: Authentication failed` / `Cannot prompt because user interactivity has been disabled` | GCM helper. See Gotchas. |
| `FAIL: no PR found for branch ...` | The draft PR does not exist yet (step 4b), or you are on the base branch. |
| `appversion.ps1` says `already at <version>` | Bump already applied today for this PR. Nothing to do. |
| `unexpected diff shape` from `appversion.ps1` | Something rewrote the file's encoding or EOLs. `git checkout -- src/WIT.UI.MVC/appsettings.json` and retry. |
| `MSBUILD : error MSB1001: Unknown switch` | PS 5.1 splat. See Gotchas. |
| Build reports `0 warnings` and warning checks pass suspiciously | Incremental build did not re-emit them. Drop `-Incremental`. |
| `CS0104: 'Assert' is an ambiguous reference` | Missing `using Assert = Xunit.Assert;`. |
| `verify.ps1` flags a stray `.md` file | You wrote the PR body into the repo. Move it to `$env:TEMP`. |
| `verify.ps1` flags `IAreaCallHelper` in `IssueService`/`CtsAuthorizationService` | Should not happen — excluded by design. If it does, the diff scoping regressed. |
