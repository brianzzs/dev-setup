---
name: code-review
description: "Review the changes since a fixed point (commit, branch, tag, or merge-base) along two axes: Standards (does the code follow this repo's documented coding standards?) and Spec (does the code match what the originating issue/spec asked for?). Runs both reviews in parallel sub-agents and reports them side by side. Use when the user wants to review a branch, a PR, work-in-progress changes, or asks to \"review since X\"."
---

Two-axis review of the diff between `HEAD` and a fixed point the user supplies:

- **Standards**: does the code conform to this repo's documented coding standards?
- **Spec**: does the code faithfully implement the originating issue / spec?

Both axes run as **parallel sub-agents** so they don't pollute each other's context, then this skill aggregates their findings.

This skill assumes nothing repo-specific exists — no issue-tracker integration, no `CODING_STANDARDS.md`. Every source below is "use it if it's there," never a hard requirement, and the baselines in steps 2–3 work with nothing but the diff itself.

## Process

### 1. Pin the fixed point

Whatever the user said is the fixed point (a commit SHA, branch name, tag, `main`, `HEAD~5`, etc.). If they didn't specify one, ask for it.

Capture the diff command once: `git diff <fixed-point>...HEAD` (three-dot, so the comparison is against the merge-base). Also note the list of commits via `git log <fixed-point>..HEAD --oneline`.

Before going further, confirm the fixed point resolves (`git rev-parse <fixed-point>`) and the diff is non-empty. A bad ref or empty diff should fail here, not inside two parallel sub-agents.

### 2. Identify the spec source

Look for the originating spec, in this order:

1. **A plan file at `.claude/plans/*.md` matching this work**, or a path the user passed directly. This is the output of a `grill-me` session — the settled decisions and seams, written down instead of left in conversation. Prefer it over everything below: it's durable across sessions and more precise than a reconstructed summary.
2. **This conversation, if the work was scoped here and no plan file exists.** E.g. an `ExitPlanMode` plan that was approved but never written to disk. Reconstruct the confirmed understanding from the transcript.
3. Issue references in the commit messages (`#123`, `Closes #45`, a ticket ID like `TLAWTH-64`) — fetch the ticket only if a connected tool/MCP can resolve it; otherwise the ID is just a label, not a blocker.
4. A spec file under `docs/`, `specs/`, or `.scratch/` matching the branch name or feature, if the repo happens to keep one.
5. If nothing is found, ask the user once where the spec is. If they say there isn't one, the **Spec** sub-agent skips and reports "no spec available" — that's a normal outcome, not a failure.

### 3. Identify the standards sources

Check for anything in the repo that documents how code should be written, such as `CODING_STANDARDS.md` or `CONTRIBUTING.md` — most repos won't have one, and that's fine.

Whether or not the repo documents anything, the Standards axis always carries the two **smell baselines** below: production-code smells and test-quality smells, both usable with nothing but the diff. Two rules bind them:

- **The repo overrides.** A documented repo standard always wins; where it endorses something a baseline would flag, suppress the smell.
- **Always a judgement call.** Each smell is a labelled heuristic ("possible Feature Envy"), never a hard violation. Like any standard here, skip anything tooling already enforces.

**Production-code baseline** — Fowler's code smells (_Refactoring_, ch.3). Each reads *what it is* → *how to fix*; match it against the diff:

- **Mysterious Name**: a function, variable, or type whose name doesn't reveal what it does or holds. → rename it; if no honest name comes, the design's murky.
- **Duplicated Code**: the same logic shape appears in more than one hunk or file in the change. → extract the shared shape, call it from both.
- **Feature Envy**: a method that reaches into another object's data more than its own. → move the method onto the data it envies.
- **Data Clumps**: the same few fields or params keep travelling together (a type wanting to be born). → bundle them into one type, pass that.
- **Primitive Obsession**: a primitive or string standing in for a domain concept that deserves its own type. → give the concept its own small type.
- **Repeated Switches**: the same `switch`/`if`-cascade on the same type recurs across the change. → replace with polymorphism, or one map both sites share.
- **Shotgun Surgery**: one logical change forces scattered edits across many files in the diff. → gather what changes together into one module.
- **Divergent Change**: one file or module is edited for several unrelated reasons. → split so each module changes for one reason.
- **Speculative Generality**: abstraction, parameters, or hooks added for needs the spec doesn't have. → delete it; inline back until a real need shows.
- **Message Chains**: long `a.b().c().d()` navigation the caller shouldn't depend on. → hide the walk behind one method on the first object.
- **Middle Man**: a class or function that mostly just delegates onward. → cut it, call the real target direct.
- **Refused Bequest**: a subclass or implementer that ignores or overrides most of what it inherits. → drop the inheritance, use composition.

**Test-quality baseline** — the same idea applied to the diff's test files, so a bad test doesn't slip through review just because it's green. This is where TDD's own discipline (see the `tdd` skill) gets a backstop instead of relying solely on whoever wrote the test:

- **Implementation-Coupled Test**: mocks an internal collaborator, reaches a private member, or asserts via a side channel (querying a database directly) instead of the interface a real caller would use. → rewrite against the public interface; delete the mock of anything the test's own module owns.
- **Tautological Assertion**: the expected value is recomputed the same way the code computes it, or is a constant asserted equal to itself — the test can't fail on a real regression. → replace with an independent literal, worked example, or spec-derived value.
- **Verification Overreach**: a call-count/argument check (`Verify(..., Times.Once)` or equivalent) is the test's primary assertion, standing in for checking the actual result. → assert on the observable output/state first; keep call verification only for genuine side effects the interface can't otherwise expose (e.g. "an email was sent").

### 4. Spawn both sub-agents in parallel

**Standards sub-agent prompt** should include:

- The full diff command and commit list.
- The list of standards-source files you found in step 3, if any, **plus both smell baselines from step 3** pasted in full (the sub-agent has no other access to them).
- The brief: "Report, per file/hunk where relevant, (a) every place the diff violates a documented standard: cite the standard (file + the rule); and (b) any baseline smell you spot: name it and quote the hunk. Distinguish hard violations from judgement calls: documented-standard breaches can be hard, but baseline smells are always judgement calls, and a documented repo standard overrides the baseline. Skip anything tooling enforces. Under 400 words."

**Spec sub-agent prompt** should include:

- The diff command and commit list.
- The path or fetched contents of the spec.
- The brief: "Report: (a) requirements the spec asked for that are missing or partial; (b) behaviour in the diff that wasn't asked for (scope creep); (c) requirements that look implemented but where the implementation looks wrong. Quote the spec line for each finding. Under 400 words."

If the spec is missing, skip the Spec sub-agent and note this in the final report.

### 5. Aggregate

Present the two reports under `## Standards` and `## Spec` headings, verbatim or lightly cleaned. Do **not** merge or rerank findings, because the two axes are deliberately separate (see _Why two axes_).

End with a one-line summary: total findings per axis, and the worst issue _within each axis_ (if any). Don't pick a single winner across axes: that's the reranking the separation exists to prevent.

## Why two axes

A change can pass one axis and fail the other:

- Code that follows every standard but implements the wrong thing → **Standards pass, Spec fail.**
- Code that does exactly what the issue asked but breaks the project's conventions → **Spec pass, Standards fail.**

Reporting them separately stops one axis from masking the other.