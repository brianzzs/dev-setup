---
name: address-pr-comments
description: 'Triage and address human-reviewer comments on the user''s own open pull requests. Use when: addressing review comments, responding to PR feedback, resolving reviewer threads on my pull requests, processing requested changes, going through comments left by a human reviewer.'
argument-hint: 'Optionally specify a repo (owner/name), PR number, or focus area (e.g. file path)'
user-invocable: true
---

# Address PR Comments

Find pull requests authored by the current user, evaluate comments left by **human reviewers**, apply changes when they make sense (or push back with a reply when they don't), and resolve each thread once handled.

## When to Use

- You want to work through human-reviewer feedback on PRs you opened.
- You need to systematically accept, discuss, or push back on requested changes.
- You want every addressed reviewer thread to end up resolved or answered.

## When NOT to Use

- Automated bot suggestions (Copilot review bot, Snyk, other lint/security bots) — those are a different, higher-volume, lower-context class of feedback; handle them separately rather than mixing them into a human-reviewer pass.
- Reviewing PRs authored by others.
- Creating or merging PRs (not in scope here).

## Procedure

### 1. Discover My Open PRs

Use `gh` to find PRs authored by the current user, scoped narrower if the user specified a repo or PR number.

```
gh pr list --author "@me" --state open --json number,title,url,repository
```

- Scoped to a repo: run from inside that repo, or pass `--repo <owner>/<name>`.
- If the user provided a specific PR (URL or number), skip search and go directly to it.

Present the list of matching PRs briefly (title, repo, number) before drilling in, unless the user already pointed at one. If there are several, ask which to process or work through them one at a time, most recently updated first.

### 2. Load PR Details and Review Threads

For the PR being processed, pull the review threads (not just top-level issue comments — comments left on a diff line live in review threads with resolve state):

```
gh api graphql -f query='
  query($owner:String!, $repo:String!, $pr:Int!) {
    repository(owner:$owner, name:$repo) {
      pullRequest(number:$pr) {
        reviewThreads(first:100) {
          nodes {
            id
            isResolved
            path
            line
            comments(first:50) {
              nodes { id author { login } body createdAt url }
            }
          }
        }
      }
    }
  }' -f owner=<owner> -f repo=<repo> -F pr=<number>
```

Also pull general (non-review) issue comments with `gh pr view <number> --json comments` if the user has left feedback outside a review thread.

### 3. Identify Human-Authored Threads

Keep threads where the comment author is **not** a bot account. Treat a comment as bot-authored (out of scope here) when `author.login` matches `copilot-pull-request-reviewer`, ends in `[bot]`, or is a known scanning tool (Snyk, Dependabot, SonarQube, etc.) — skip those.

Filter further:
- Keep threads where `isResolved` is `false`.
- Group by `path` (file) to batch related edits efficiently.
- Note the reviewer's identity — tone and required rigor for a reply should match who asked (tech lead vs. peer vs. junior reviewer questions may warrant different depth).

### 4. Evaluate Each Comment

For every open human thread, decide one of these outcomes before touching code:

| Outcome | Criteria | Action |
|---|---|---|
| **Apply as requested** | The ask is clear and correct | Make the change |
| **Apply with a twist** | The concern is valid but the literal suggestion isn't the best fix | Implement the better fix; explain the deviation in the reply |
| **Push back** | The suggestion is incorrect, out of scope, or conflicts with project conventions | Reply explaining why, do not change code, leave the thread open for the reviewer to respond |
| **Ask for clarification** | The comment is ambiguous or missing context | Reply with a clarifying question, leave the thread open |

Evaluation checklist:

1. Read the file around the referenced line so you understand context.
2. Confirm the change compiles / matches surrounding patterns (naming, style, existing helpers).
3. Confirm it does not regress behavior or break callers.
4. Stay within the PR's scope — do not pull in unrelated refactors just because a reviewer's comment brushed against them; call out scope creep back to the user instead.
5. When genuinely unsure, treat it as **Ask for clarification** rather than guessing.

### 5. Apply Changes

For "Apply as requested" / "Apply with a twist" outcomes:

- Read the file before editing.
- Apply the minimal change that satisfies the comment.
- Batch multiple comments on the same file into grouped edits when possible.
- Do not modify code outside a comment's scope.
- Re-run relevant local validation (lint/build/tests) when it's fast; otherwise note that verification is pending.

### 6. Reply and Resolve Threads

For every human thread that was handled:

- If code changed, a short reply is optional but often good practice for a non-obvious deviation ("Applied with X instead of Y because Z").
- If pushing back or asking for clarification, **always** reply — do not resolve without a response, since the reviewer needs to see the explanation.
- Post a reply with:

```
gh api graphql -f query='
  mutation($threadId:ID!, $body:String!) {
    addPullRequestReviewThreadReply(input:{pullRequestReviewThreadId:$threadId, body:$body}) {
      comment { id }
    }
  }' -f threadId=<thread-id> -f body="<reply text>"
```

- Resolve a thread only after it has been addressed (code changed) or replied to (pushback/clarification):

```
gh api graphql -f query='
  mutation($threadId:ID!) {
    resolveReviewThread(input:{threadId:$threadId}) { thread { isResolved } }
  }' -f threadId=<thread-id>
```

Do not resolve a thread you have not personally addressed in this pass, and never resolve a thread on someone else's behalf without a reply first.

### 7. Summarize

Report back with:

- The PR(s) processed (repo + number + title).
- A table of threads handled: file/line, short comment summary, outcome (Applied / Applied-with-twist / Pushed-back / Clarification-asked), resolved (yes/no).
- Any threads left open and why.
- Any code changes that still need to be committed and pushed — do not push automatically unless the user explicitly asks.

## Notes

- This skill only touches human-authored review threads. Leave bot-authored suggestions (Copilot review bot, Snyk, etc.) to a dedicated bot-triage pass.
- Resolving a thread does not delete the comment or notify beyond GitHub's normal activity feed — if the reviewer needs an explicit heads-up, say so and let the user decide whether to also comment on the PR itself.
- If multiple PRs match and the user did not narrow scope, process them one at a time and pause for confirmation between PRs when the change volume is non-trivial.
