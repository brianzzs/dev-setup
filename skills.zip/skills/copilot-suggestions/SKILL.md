---
name: copilot-suggestions
description: "Triage Copilot review suggestions on the user's own open pull requests. Use when: reviewing my open PRs, processing copilot suggestions, addressing copilot review comments on my PRs, clearing copilot bot feedback, going through copilot code review suggestions, resolving copilot threads on my pull requests."
argument-hint: "Optionally specify a repo (owner/name), PR number, or focus area (e.g. file path)"
user-invocable: true
---

# Process Copilot Suggestions on My Open PRs

Find pull requests authored by the current user, evaluate Copilot's review suggestions on them, apply changes when they make sense (improving on them when a better solution exists), and resolve each thread either way.

## When to Use

- You want to triage Copilot's automated review feedback on PRs you opened.
- You need to systematically accept, improve, or dismiss Copilot suggestions across one or more of your PRs.
- You want every Copilot thread on your open PRs to end up resolved.

## When NOT to Use

- Addressing comments from human reviewers — use the `address-pr-comments` skill instead.
- Reviewing PRs authored by others.
- Creating or merging PRs (not in scope here).

## Procedure

### 1. Discover My Open PRs

Use `gh` to find PRs authored by the current user, scoped narrower if the user specified a repo or PR number.

```
gh pr list --author "@me" --state open --json number,title,url,repository
```

- Scoped to a repo: run from inside that repo, or pass `--repo <owner>/<name>`.
- If the user provided a specific PR (URL or number), skip search and go directly to it.

Present the list of matching PRs briefly (title, repo, number) before drilling in, unless the user already pointed at one. If there are several, ask which to process or work through them one at a time, most recently updated first.

### 2. Load PR Details and Review Threads

For the PR being processed, pull the review threads (not just top-level issue comments — comments left on a diff line live in review threads with resolve state):

```
gh api graphql -f query='
  query($owner:String!, $repo:String!, $pr:Int!) {
    repository(owner:$owner, name:$repo) {
      pullRequest(number:$pr) {
        reviewThreads(first:100) {
          nodes {
            id
            isResolved
            isOutdated
            path
            line
            comments(first:50) {
              nodes { id author { login } body createdAt url }
            }
          }
        }
      }
    }
  }' -f owner=<owner> -f repo=<repo> -F pr=<number>
```

**Refresh check**: if the PR was updated in the last 3 minutes (new commits pushed), re-run the query so you do not act on stale thread data.

### 3. Identify Copilot Threads

From the review thread data, isolate threads authored by Copilot. Treat a comment as a Copilot suggestion when **any** of these are true:

- `author.login` is `copilot-pull-request-reviewer`, `github-copilot[bot]`, `copilot[bot]`, or another login containing `copilot`.
- The comment body is a structured Copilot review block (often starts with a severity prefix like `[nitpick]`, `[suggestion]`, or contains a fenced ```suggestion block).

Filter further:
- Keep threads where `isResolved` is `false`.
- Group by `path` (file) to batch edits efficiently.
- Note threads where the GraphQL response doesn't allow resolution (rare, but treat any resolve-mutation error as "skip resolving, but may still apply the change").

### 4. Evaluate Each Suggestion

For every Copilot thread, decide one of three outcomes before touching code:

| Outcome | Criteria | Action |
|---|---|---|
| **Accept as-is** | Suggestion is correct, idiomatic, and minimal | Apply the suggested diff verbatim |
| **Accept with improvement** | Suggestion identifies a real issue but the proposed fix is incomplete, wrong style for this codebase, or has a better alternative | Implement the better fix; briefly note the deviation when summarizing |
| **Dismiss** | Suggestion is wrong, irrelevant, contradicts project conventions, asks for a change outside the PR scope, or is a low-value nitpick the user wouldn't want | Make no code change |

Evaluation checklist:

1. Read the file around the referenced line so you understand context.
2. Check that the suggestion compiles / matches the surrounding patterns (naming, style, existing helpers).
3. Confirm it does not regress behavior or break callers.
4. Make sure it stays within the PR's scope — do not pull in unrelated refactors.
5. If the suggestion is ambiguous or you cannot verify safely, treat it as **Dismiss** and note it in the summary instead of guessing.

### 5. Apply Changes

For Accept / Accept-with-improvement outcomes:

- Read the file before editing.
- Apply the minimal change that satisfies the suggestion.
- Group multiple suggestions on the same file into batched edits when possible.
- Do not modify code outside the suggestion's scope.
- Re-run any obvious local validation (lint/build/tests) only if it is fast and the user typically expects it; otherwise note that verification is pending.

### 6. Resolve Threads

For **every** Copilot thread that has been handled — whether accepted, improved, or dismissed — resolve it:

```
gh api graphql -f query='
  mutation($threadId:ID!) {
    resolveReviewThread(input:{threadId:$threadId}) { thread { isResolved } }
  }' -f threadId=<thread-id>
```

Rules:
- Skip threads that are already `isResolved: true`.
- Never resolve threads that are not from Copilot.
- If the user wants a reply explaining a dismissal, post one before resolving:

```
gh api graphql -f query='
  mutation($threadId:ID!, $body:String!) {
    addPullRequestReviewThreadReply(input:{pullRequestReviewThreadId:$threadId, body:$body}) {
      comment { id }
    }
  }' -f threadId=<thread-id> -f body="<reply text>"
```

### 7. Summarize

Report back with:

- The PR(s) processed (repo + number + title).
- A table or list of Copilot threads with: file, short suggestion summary, outcome (Accepted / Improved / Dismissed), resolved (yes/no).
- Any threads left unresolved and why.
- Any code changes that still need to be committed and pushed.

Do **not** push commits or update the PR description unless the user explicitly asks.

## Notes

- This skill only touches Copilot-authored review threads. Leave human-authored comments alone — those belong to `address-pr-comments`.
- "Mark as resolved" means calling the resolve-thread mutation; it does not delete the comment or post a reply. If the user wants a reply explaining a dismissal, post one before resolving.
- If multiple PRs match and the user did not narrow the scope, process them one PR at a time and pause for confirmation between PRs when the change volume is non-trivial.
